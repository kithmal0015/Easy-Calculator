package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    TextView textView2, textView3;
    MaterialButton cbtn, openbtn, closebtn;
    MaterialButton mulbtn, devbtn, subbtn, plusbtn, sumbtn;
    MaterialButton sevenbtn, eightbtn, ninebtn, fourbtn, fivebtn, sixbtn, onebtn, twobtn, threebtn, zerobtn;
    MaterialButton acbtn, dotbtn, historybtn;

    private String firstNumber = "";
    private String secondNumber = "";
    private String operator = "";
    private boolean isOperatorSelected = false;

    private List<String> historyList = new ArrayList<>(); // Stores calculation history

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        textView2 = findViewById(R.id.textView2);
        textView3 = findViewById(R.id.textView3);
        cbtn = findViewById(R.id.cbtn);
        openbtn = findViewById(R.id.openbtn);
        closebtn = findViewById(R.id.closebtn);
        mulbtn = findViewById(R.id.mulbtn);
        devbtn = findViewById(R.id.devbtn);
        subbtn = findViewById(R.id.subbtn);
        plusbtn = findViewById(R.id.plusbtn);
        sumbtn = findViewById(R.id.sumbtn);
        sevenbtn = findViewById(R.id.sevenbtn);
        eightbtn = findViewById(R.id.eightbtn);
        ninebtn = findViewById(R.id.ninebtn);
        fourbtn = findViewById(R.id.fourbtn);
        fivebtn = findViewById(R.id.fivebtn);
        sixbtn = findViewById(R.id.sixbtn);
        onebtn = findViewById(R.id.onebtn);
        twobtn = findViewById(R.id.twobtn);
        threebtn = findViewById(R.id.threebtn);
        zerobtn = findViewById(R.id.zerowbtn);
        acbtn = findViewById(R.id.acbtn);
        dotbtn = findViewById(R.id.dotbtn);
        historybtn = findViewById(R.id.historybtn);

        setClickListeners();
    }

    private void setClickListeners() {
        MaterialButton[] buttons = {cbtn, openbtn, closebtn, mulbtn, devbtn, subbtn, plusbtn, sumbtn,
                sevenbtn, eightbtn, ninebtn, fourbtn, fivebtn, sixbtn, onebtn, twobtn, threebtn, zerobtn,
                acbtn, dotbtn, historybtn};

        for (MaterialButton button : buttons) {
            button.setOnClickListener(this);
        }
    }

    @Override
    public void onClick(View v) {
        MaterialButton button = (MaterialButton) v;
        String buttonText = button.getText().toString();

        if (buttonText.matches("[0-9]") || buttonText.equals(".")) {
            if (isOperatorSelected) {
                secondNumber += buttonText;
            } else {
                firstNumber += buttonText;
            }
            textView3.append(buttonText);

        } else if (buttonText.matches("[+\\-*/()]")) {
            if (!firstNumber.isEmpty()) {
                operator = buttonText;
                isOperatorSelected = true;
                textView3.append(" " + buttonText + " ");
            }

        } else if (buttonText.equals("=")) {

            if (!firstNumber.isEmpty() && !secondNumber.isEmpty()) {
                double result = calculateResult();
                String equation = firstNumber + " " + operator + " " + secondNumber + " = " + result;

                historyList.add(equation);

                textView3.setText(textView2.getText().toString());
                textView2.setText(String.valueOf(result));


                firstNumber = String.valueOf(result);
                secondNumber = "";
                operator = "";
                isOperatorSelected = false;
            }

        } else if (buttonText.equals("AC")) {

            firstNumber = "";
            secondNumber = "";
            operator = "";
            isOperatorSelected = false;
            textView2.setText("");
            textView3.setText("");

        } else if (buttonText.equals("C")) {

            if (isOperatorSelected && !secondNumber.isEmpty()) {
                secondNumber = secondNumber.substring(0, secondNumber.length() - 1);
            } else if (!operator.isEmpty()) {
                operator = "";
                isOperatorSelected = false;
            } else if (!firstNumber.isEmpty()) {
                firstNumber = firstNumber.substring(0, firstNumber.length() - 1);
            }

            String currentText = textView3.getText().toString();
            if (!currentText.isEmpty()) {
                textView3.setText(currentText.substring(0, currentText.length() - 1));
            }

        } else if (buttonText.equals("History")) {
            showHistory();
        }
    }

    private void showHistory() {
        if (historyList.isEmpty()) {
            textView3.setText("No History");
            return;
        }

        StringBuilder historyText = new StringBuilder();
        for (String entry : historyList) {
            historyText.append(entry).append("\n");
        }

        textView3.setText(historyText.toString());
    }

    public double calculateResult() {
        double num1 = Double.parseDouble(firstNumber);
        double num2 = Double.parseDouble(secondNumber);

        switch (operator) {
            case "+":
                return num1 + num2;
            case "-":
                return num1 - num2;
            case "*":
                return num1 * num2;
            case "/":
                return num2 != 0 ? num1 / num2 : 0;
            default:
                return 0;
        }
    }
}
